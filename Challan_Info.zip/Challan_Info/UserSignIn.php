<?php
session_start();

$Email = $_POST['Email'];
$Password = $_POST['Password'];

// database connection
$conn = new mysqli('localhost', 'root', '', 'Full_stack');
if ($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
} else {
    // Using prepared statement to prevent SQL injection
    $stmt = $conn->prepare('SELECT * FROM user WHERE Email = ?');
    $stmt->bind_param('s', $Email);
    $stmt->execute();
    $stmt_result = $stmt->get_result();

    if ($stmt_result->num_rows > 0) {
        $data = $stmt_result->fetch_assoc();
        $Name = $data['Name'];
        // Checking password
        if ($data['Password'] === $Password) { // Change $password to $Password
            // Redirecting to USCI.html upon successful login
            $_SESSION['Email'] = $Email;
            $_SESSION["Name"] = $Name;
            echo "<h2>Sign In Successfully</h2>";
            echo '<script>window.location.href = "User.php";</script>';
            exit();
        } else {
            // Password doesn't match, display pop-up message on login.html
            echo "<script>
                    alert('Invalid Username or Password');
                    window.history.back();
                  </script>";
            exit();
        }
    } else {
        // No user found with the provided email, display pop-up message on login.html
        echo "<script>
                alert('Invalid Username or Password');
                window.history.back();
              </script>";
        exit();
    }
}
?>