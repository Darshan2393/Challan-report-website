<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChallanInfo.</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- Iconscout Link  -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.6/css/unicons.css">
    <style>
        .User-txt {
            font-size: 18px;
            font-weight: 500;
            color: #c73335e7;
        }

        .header .logo img {
            height: 50px;
            width: auto;
        }

        .header .navbar a {
            margin-left: 2rem;
            font-size: 1.9rem;
            font-weight: 500;
            color: #c73335e7;
        }

        .features .box-container .box .content p {
            font-size: 1.5rem;
            line-height: 2;
            margin: 10px;
        }

        .features .box-container .box .content p {
            position: absolute;
            left: 50%;
            bottom: 2rem;
            width: 80%;
            transform: translate(-50%, -50%);
            opacity: 0;
            transition: opacity 0.3s ease, transform 0.3s ease;
            /* Added transition for opacity and transform */
        }

        .features .box-container .box:hover .content p,
        .features .box-container .box:hover .content .btn {
            opacity: 1;
            transform: translate(-50%, -50%) scale(1.1);
            /* Scale up a bit when appearing */
        }
    </style>
</head>

<body>
    <header class="header">
        <a href="#" class="logo"><img src="images/CHALLAN INFO.png"></a>

        <nav class="navbar">
            <div id="nav-close" class="fas fa-times"></div>
            <?php
            // Check if the user is logged in
            if (isset($_SESSION['Name'])) {
                // User is logged in, display their name and logout link
                echo '<span class="User-txt" ;">Hello ' . $_SESSION['Name'] . '</span> !';
                echo '&nbsp;';
                echo '&nbsp;';
                echo '<a href="#home">home</a>';
                echo '<a href="#features">Features</a>';
                echo '<a href="#contact">contact</a>';
                echo '<a class="nav-links" href="ChallanInfo.html" id="logout">Sign Out</a>';
            } else {
                // User is not logged in, display login link
                echo '<a class="nav-link" href="login.html" ;">Sign In</a>';
            }
            ?>
        </nav>
        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
        </div>
    </header>


    <section class="home" id="home">

        <div class="wrapper">

            <div class="box" style="background: url(images/Untitled\ design.png) no-repeat;">
                <!-- <div class="box" style="background-color: #183357;"> -->
                <div class="content">
                    <span>Drive Right,</span>
                    <h3>Pay Less!</h3>
                    <p>Hit the brakes on penalties! "Keep your driving record clean and your expenses lean"</p>
                    <a href="#features" class="btn">Check Penalties</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Adventure section -->
    <section class="features" id="features">

        <h1 class="heading">Features</h1>

        <div class="box-container">

            <div class="box">
                <div class="image">
                    <img src="images\e-challan-status-online-new.png" alt="">
                </div>
                <div class="content">
                    <h3>Challan History</h3>
                    <p>"To improve your driving habits, review your past penalties. To make your driving safer, review previous infractions and fines. Keep yourself educated, grow from past mistakes, and drive more skillfully. In order to drive more safely in the future, take control of your driving record."</p>
                    <a href="Challan_History.html" class="btn">Check now</a>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="images/receipt.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Challan Receipt</h3>
                    <p>Efficiently track and manage your fines and payments with our user-friendly receipt feature. Stay updated on all your challan transactions effortlessly. Simplify record-keeping and ensure compliance with ease.".</p>
                    <a href="Payment_receipt.php" class="btn">explore now</a>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="images/Teen-Traffic-Violation-Penalties.webp" alt="">
                </div>
                <div class="content">
                    <h3>Latest Traffic Violations and Their Penalties</h3>
                    <p>Maintaining legal compliance requires knowledge. Explore our section on violations and penalties to get up to date information on any legal repercussions. To safeguard your interests and yourself, take aggressive measures.</p>
                    <a href="Traffic_Rules.html" class="btn">Explore Now</a>
                </div>
            </div>


        </div>

        </div>

    </section>
    </section>

    <section class="category" id="category">

        <h1 class="heading">Safety Spotlight!</h1>

        <div class="box-container">

            <div class="box">
                <img src="images\6 Well Known Marketing Disasters In History & Lessons To Learn.jpeg" alt="BungeeJumpingImg">
                <h3>"Speed Sense: Stay Within the Limits"</h3>
                <p>"The road's heartbeat is in its speed limits. Tune in to its rhythm for a safer ride."
                </p>
                <a href="https://en.wikipedia.org/wiki/Seat_belt" class="btn">read more</a>
            </div>

            <div class="box">
                <img src="images\Safe driving creative poster_ Volkswagen.jpeg" alt="ZipLinesImg">
                <h3>"Click & Protect: The Seat Belt Mantra"</h3>
                <p>"Make the click that counts. Promise to protect yourself and your loved ones–always buckle up."</p>
                <a href="https://injuryfacts.nsc.org/motor-vehicle/motor-vehicle-safety-issues/speeding/" class="btn" target="_self">read more</a>
            </div>

            <div class="box">
                <img src="images\Driving awareness banner.jpeg" alt="canoeingImg">
                <h3> "Helmet Harbor: Anchor for Safety"</h3>
                <p>"Harboring safety, anchoring your ride. Set sail with confidence, anchored by your helmet."</p>
                <a href="https://www.tataaig.com/knowledge-center/two-wheeler-insurance/importance-of-wearing-helmet-on-two-wheelers" class="btn">read more</a>
            </div>

        </div>

    </section>

    <section class="contact" id="contact">

        <div class="wrapper1">

            <div class="title1">

                <h1>Contact us</h1>

            </div>

            <div class="contact-form">

                <form method="post" action="contact_us.php">

                    <div class="input-fields">



                        <input type="text" class="input" placeholder="Name" name="name" required>

                        <input type="email" class="input" placeholder="Email Address" name="email" pattern=".+@gmail\.com" required>

                        <input type="phone" class="input" placeholder="Phone" name="phone" required>

                        <input type="text" class="input" placeholder="Subject" name="subject" required>

                    </div>

                    <div class="msg">

                        <textarea placeholder="Message" name="message"></textarea> <br>

                        <div class="btn1"><button type="submit">send <i class="uil uil-message"></i></div>

                    </div>

                </form>


            </div>

        </div>
    </section>
    <section class="footer">

        <div class="box-container">

            <div class="box">
                <h3>Quick links</h3>
                <a href="#home">home</a>
                <a href="#features">Features</a>
                <a href="#category">Be Aware</a>
                <a href="#contact">Contact</a>
            </div>

            <div class="box">
                <h3>extra links</h3>
                <a href="#contact">ask questions</a>
                <a href="#">terms of use</a>
                <a href="#">privacy policy</a>
            </div>

            <div class="box">
                <h3>contact info</h3>
                <a href="#"> <i class="fas fa-phone"></i> +91 9825486596 </a>
                <a href="#"> <i class="fas fa-envelope"></i>darshan2003patel@gmail.com </a>
            </div>

            <div class="box">
                <h3>follow us</h3>
                <a href="https://www.instagram.com/yash_srivastav_"> <i class="fab fa-instagram"></i> instagram </a>
                <a href="https://www.linkedin.com/in/yash-srivastav/"> <i class="fab fa-linkedin"></i> linkedin </a>
                <a href="https://github.com/Yash-srivastav16"> <i class="fab fa-github"></i> github </a>
            </div>
        </div>
        <div class="credit">created by <span>Darshan Patel</span> | all rights reserved!</div>
    </section>
    <!-- footer section ends -->
    <script src="js/script.js"></script>
</body>

</html>