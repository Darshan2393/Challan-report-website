<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User Info</title>
</head>
<body>
    <?php
    // Database connection
    $servername = "localhost"; // Assuming your MySQL server is on localhost
    $username = "root"; // MySQL username (default is root)
    $password = ""; // MySQL password (default is empty)
    $dbname = "userinfo"; // Name of your database

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Fetching form data using $_POST
        $name = $_POST['name'];
        $email = $_POST['email'];
        $contact = $_POST['contact'];

        // SQL query to insert data into table
        $sql = "INSERT INTO number_userinfo (Name, Email, Contact_no) VALUES ('$name', '$email', '$contact')";

        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    ?>
    
    <h2>Add User Info</h2>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required><br><br>
        
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>
        
        <label for="contact">Contact No:</label>
        <input type="text" id="contact" name="contact" required><br><br>
        
        <input type="submit" value="Submit">
    </form>
</body>
</html>
