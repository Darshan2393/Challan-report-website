<?php
// Database connection parameters
$servername = "localhost"; // Assuming MySQL is running on localhost
$username = "root"; // Default username for MySQL in XAMPP
$password = ""; // Default password for MySQL in XAMPP
$database = "full_stack2"; // Name of the database
$table = "payment"; // Name of the table

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Variable to track whether the payment was successful
$payment_successful = false;

// Assuming you want to insert data into the payment table from the form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $address = $_POST['address'];
    $state = $_POST['state'];
    $zip_code = $_POST['zip_code'];
    $card_number = $_POST['card_number'];
    $exp_month = $_POST['exp_month'];
    $exp_year = $_POST['exp_year'];
    $cvv = $_POST['cvv'];
    $amount = $_POST['amount'];

    // SQL to insert data into payment table
    $sql = "INSERT INTO $table (name, email, number, address, state, zip_code, card_number, exp_month, exp_year, cvv, amount)
    VALUES ('$name', '$email', '$number', '$address', '$state', '$zip_code', '$card_number', '$exp_month', '$exp_year', '$cvv', '$amount')";

    if ($conn->query($sql) === TRUE) {
        $payment_successful = true;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment Result</title>
    <script>
        // Function to show a pop-up message and redirect after 3 seconds
        function showMessageAndRedirect() {
            alert("Payment successful!");
            setTimeout(function() {
                window.location.href = "user.php";
            }, 3); // 3000 milliseconds = 3 seconds
        }

        // Check if payment was successful and show message if it was
        <?php if ($payment_successful) { ?>
            window.onload = showMessageAndRedirect;
        <?php } ?>
    </script>
</head>
<body>
</body>
</html>
