<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Payment Receipt</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .container {
            display: flex;
            flex-wrap: wrap;
            font-size: medium;
            margin: 10px;
            gap: 20px;
        }

        .card {
            border: 2px solid #333;
            border-radius: 10px;
            padding: 20px;
            max-width: 600px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .card h3 {
            margin-top: 0;
            text-align: center;
            color: #333;
        }

        .card p {
            margin: 0;
            padding: 5px 0;
            color: #666;
        }

        .card p strong {
            color: #333;
        }
    </style>
</head>

<body>
    <header class="header">
        <a href="User.php" class="logo"><img src="images/CHALLAN INFO.png"></a>

        <nav class="navbar">

            </li>
            <div id="nav-close" class="fas fa-times"></div>
            <a href="User.php">home</a>
        </nav>
        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
        </div>
    </header>
    <br><br><br><br><br><br><br>
    <div class="container">
        <?php
        // Database connection parameters
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "full_stack2";
        $table = "payment";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $database);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch payment data from the database
        $sql = "SELECT * FROM $table";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output data of each row
            while ($row = $result->fetch_assoc()) {
        ?>
                <div class="card">
                    <h3>Payment Receipt</h3>
                    <p><strong>Name:</strong> <?php echo $row['name']; ?></p>
                    <p><strong>Email:</strong> <?php echo $row['email']; ?></p>
                    <p><strong>Contact Number:</strong> <?php echo $row['number']; ?></p>
                    <p><strong>Amount:</strong> <?php echo $row['amount']; ?></p>
                    <p><strong>Status:</strong> <?php echo $row['Status']; ?></p>
                </div>
        <?php
            }
        } else {
            echo "0 results";
        }
        // Close connection
        $conn->close();
        ?>
    </div>

    <section class="footer">

        <div class="box-container">

            <div class="box">
                <h3>Quick links</h3>
                <a href="User.php">home</a>
            </div>

            <div class="box">
                <h3>extra links</h3>
                <a href="#contact">ask questions</a>
                <a href="#">terms of use</a>
                <a href="#">privacy policy</a>
            </div>

            <div class="box">
                <h3>contact info</h3>
                <a href="#"> <i class="fas fa-phone"></i> +91 9825486596 </a>
                <a href="#"> <i class="fas fa-envelope"></i>darshan2003patel@gmail.com </a>
            </div>

            <div class="box">
                <h3>follow us</h3>
                <a href="https://www.instagram.com/yash_srivastav_"> <i class="fab fa-instagram"></i> instagram </a>
                <a href="https://www.linkedin.com/in/yash-srivastav/"> <i class="fab fa-linkedin"></i> linkedin </a>
                <a href="https://github.com/Yash-srivastav16"> <i class="fab fa-github"></i> github </a>
            </div>
        </div>
        <div class="credit">created by <span>Darshan Patel</span> | all rights reserved!</div>
    </section>
</body>

</html>