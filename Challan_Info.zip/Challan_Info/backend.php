<?php
// Connect to database
$servername = "localhost";
$dbname = "userinfo";

// Create connection
$conn = new mysqli($servername, 'root', '', $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get numberplate from GET parameter
$numberplate = $_GET['numberplate'];

// Prepare and execute SQL query
$sql = "SELECT Name, Email, Contact_no FROM number_userinfo WHERE Car_numberplate = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $numberplate);
$stmt->execute();
$result = $stmt->get_result();

// Fetch and return data as JSON
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode($row);
} else {
    echo json_encode(["error" => "No data found"]);
}

$stmt->close();
$conn->close();
?>
