<?php
// Database connection
$servername = "localhost";
$username = "root"; // Change this if you have a different MySQL username
$password = ""; // Change this if you have set a MySQL password
$dbname = "full_stack";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$name = $_POST['name'];
$contact = $_POST['contact'];
$email = $_POST['email'];
$vehicle = $_POST['vehicle'];
$date = $_POST['date'];
$city = $_POST['city'];
$penalty = $_POST['penalty'];
$violation = $_POST['violation'];

// Insert data into database
$sql = "INSERT INTO Challan_History (Name, Contact_No, Email, Vehicle_Number_Plate, Date, City, Penalty,Violation) VALUES ('$name', '$contact', '$email', '$vehicle', '$date', '$city', '$penalty', '$violation)";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
