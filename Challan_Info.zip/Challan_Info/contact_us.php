<?php
// Database connection parameters
$servername = "localhost";
$username = "root"; // Default username for XAMPP
$password = ""; // No password set by default in XAMPP
$dbname = "full_stack2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$subject = $_POST['subject'];
$message = $_POST['message'];

$sql = "INSERT INTO contact(Name, Email, Phone, Subject, Message) VALUES ('$name','$email','$phone','$subject','$message')";
$result = mysqli_query($conn, $sql);
if (!$result) {
    echo "error: ", mysqli_error($conn);
    exit;
}

// Close the database connection
mysqli_close($conn);

// Display pop-up message and redirect using JavaScript
echo "<script>alert('We will contact you soon'); window.location='user.php';</script>";
?>
