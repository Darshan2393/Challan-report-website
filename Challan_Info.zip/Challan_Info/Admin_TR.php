<?php
$servername = "localhost";
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "full_stack";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if data is posted for addition
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $trafficViolation = $_POST['trafficViolation'];
    $vehicleType = $_POST['vehicleType'];
    $penalty = $_POST['penalty'];

    $sql = "INSERT INTO traffic_rules (Traffic_Violation, Vehicle_Type, Penalty) VALUES ('$trafficViolation', '$vehicleType', '$penalty')";
    
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Check if data is posted for deletion
if ($_SERVER["REQUEST_METHOD"] == "DELETE") {
    parse_str(file_get_contents("php://input"), $del_vars);
    $id = $del_vars['id'];
    $sql = "DELETE FROM traffic_rules WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Fetch data if GET request
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $sql = "SELECT * FROM traffic_rules";
    $result = $conn->query($sql);

    $data = array();
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }

    echo json_encode($data);
}

$conn->close();
?>
