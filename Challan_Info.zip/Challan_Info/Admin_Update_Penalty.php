<?php
$servername = "localhost";
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "full_stack";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and bind the INSERT statement
$stmt = $conn->prepare("INSERT INTO challan_history (Name, Email, Contact_No, Vehicle_Number_Plate, Date, City, Penalty, Violation) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssss", $name, $email, $contact_no, $vehicle_number, $date, $city, $penalty, $violation);

// Set parameters and execute
$name = $_POST['name'];
$email = $_POST['email'];
$contact_no = $_POST['contact_no'];
$vehicle_number = $_POST['vehicle_number'];
$date = $_POST['date'];
$city = $_POST['city'];
$penalty = $_POST['penalty'];
$violation = $_POST['violation'];

$stmt->execute();

echo "Penalty information added successfully.";

$stmt->close();
$conn->close();
?>
