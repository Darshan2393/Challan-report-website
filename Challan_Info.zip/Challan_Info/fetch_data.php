<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "full_stack2"; // Change this to your database name

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch image paths from the database
$sql = "SELECT image FROM fetched_unmber_plate"; // Change 'fetched_number_plate' to your actual table name
$result = $conn->query($sql);

$data = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        // Add each image path to the $data array
        $data[] = $row;
    }
}

// Output the image paths as JSON
header('Content-Type: application/json');
echo json_encode($data);

$conn->close();
?>
