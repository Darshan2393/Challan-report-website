<?php
$Name = $_POST['Name'];
$Email = $_POST['Email'];
$Password = $_POST['Password'];
$Confirm_password = $_POST['Confirm_password'];



// Database connection
$conn = new mysqli('localhost', 'root', '', 'Full_stack');
if ($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
} else {
    $stmt = $conn->prepare("INSERT INTO admin (Name, Email, Password, Confirm_password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param('ssss', $Name, $Email, $Password, $Confirm_password);
    $stmt->execute(); 
    echo "Registration Successful...";
    $stmt->close();
    $conn->close();

    // Redirect to login page
    header("Location: AdminSignIn.html");
    exit();
}
?>
